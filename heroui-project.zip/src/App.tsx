import React from "react";
import { Button, Divider, Image } from "@heroui/react";
import { Icon } from "@iconify/react";
import { Hero } from "./components/hero";
import { Features } from "./components/features";
import { Products } from "./components/products";
import { Testimonials } from "./components/testimonials";
import { Contact } from "./components/contact";
import { Footer } from "./components/footer";
import { Navbar } from "./components/navbar";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-amber-50/30 font-sans relative overflow-hidden">
      {/* Add decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full -z-10 overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-amber-200/10 to-amber-100/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-amber-200/10 to-amber-100/5 rounded-full blur-3xl"></div>
      </div>
      <main className="container mx-auto px-4 py-12 md:py-20 relative z-10">
        <SimplifiedHero />
      </main>
    </div>
  );
}

const SimplifiedHero = () => {
  return (
    <div className="flex flex-col items-center text-center max-w-3xl mx-auto">
      {/* Enhanced logo with animation */}
      <div className="flex items-center gap-3 mb-10 bg-white/50 backdrop-blur-sm px-6 py-3 rounded-full shadow-sm border border-amber-100">
        <Icon icon="lucide:droplets" className="text-amber-500 text-3xl" />
        <span className="text-2xl md:text-3xl font-semibold tracking-tight bg-gradient-to-r from-amber-600 to-amber-400 bg-clip-text text-transparent">VELV AROMA</span>
      </div>
      
      <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight mb-8 bg-gradient-to-r from-gray-900 via-amber-800 to-gray-900 bg-clip-text text-transparent">
        Преміум аромати за <span className="text-amber-500">доступною ціною</span>
      </h1>
      
      <p className="text-foreground-600 text-lg max-w-xl mb-10 leading-relaxed">
        Європейські олії найвищої якості з концентрацією 50%, які не поступаються оригіналам у стійкості та розкритті аромату.
      </p>
      
      {/* Enhanced feature badges */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-14">
        <div className="flex items-center gap-3 px-4 py-2 bg-white/70 backdrop-blur-sm rounded-full shadow-sm border border-amber-100">
          <div className="bg-amber-500/10 p-2 rounded-full">
            <Icon icon="lucide:check-circle" className="text-amber-500" />
          </div>
          <span className="font-medium">Висока якість</span>
        </div>
        
        <div className="flex items-center gap-3 px-4 py-2 bg-white/70 backdrop-blur-sm rounded-full shadow-sm border border-amber-100">
          <div className="bg-amber-500/10 p-2 rounded-full">
            <Icon icon="lucide:clock" className="text-amber-500" />
          </div>
          <span className="font-medium">Стійкість 72 години</span>
        </div>
        
        <div className="flex items-center gap-3 px-4 py-2 bg-white/70 backdrop-blur-sm rounded-full shadow-sm border border-amber-100">
          <div className="bg-amber-500/10 p-2 rounded-full">
            <Icon icon="lucide:wallet" className="text-amber-500" />
          </div>
          <span className="font-medium">Доступна ціна</span>
        </div>
      </div>
      
      <h2 className="text-xl md:text-2xl font-semibold mb-8 bg-gradient-to-r from-amber-700 to-amber-500 bg-clip-text text-transparent">
        Звʼяжіться з нами в зручному для Вас додатку
      </h2>
      
      {/* Enhanced social media buttons */}
      <div className="flex flex-wrap justify-center gap-6 mb-10">
        <Button
          size="lg"
          variant="flat"
          className="bg-gradient-to-r from-purple-600 to-pink-500 text-white hover:opacity-90 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
          as="a"
          href="https://www.instagram.com/velv_aroma/"
          target="_blank"
          startContent={<Icon icon="logos:instagram-icon" className="text-2xl" />}
        >
          Instagram
        </Button>
        <Button
          size="lg"
          variant="flat"
          className="bg-black text-white hover:opacity-90 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
          as="a"
          href="https://www.tiktok.com/@velv_aroma?lang=uk-UA"
          target="_blank"
          startContent={<Icon icon="logos:tiktok-icon" className="text-2xl" />}
        >
          TikTok
        </Button>
        <Button
          size="lg"
          variant="flat"
          className="bg-gradient-to-r from-blue-600 to-blue-400 text-white hover:opacity-90 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
          as="a"
          href="https://t.me/velv_aroma_shop"
          target="_blank"
          startContent={<Icon icon="logos:telegram" className="text-2xl" />}
        >
          Telegram
        </Button>
      </div>
      
      <p className="text-foreground-500 text-sm mt-6 bg-white/50 backdrop-blur-sm px-4 py-2 rounded-full shadow-sm border border-amber-100">
        © 2024 VELV AROMA. Всі права захищені.
      </p>
    </div>
  );
};