import React from "react";
import { Button, Image } from "@heroui/react";
import { Icon } from "@iconify/react";

export const Hero = () => {
  return (
    <section id="home" className="relative overflow-hidden bg-gradient-to-b from-amber-50/50 to-background pt-16 pb-24 md:pt-24 md:pb-32">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute -top-24 -right-24 w-64 h-64 rounded-full bg-amber-100/30 blur-3xl"></div>
        <div className="absolute top-1/2 -left-24 w-48 h-48 rounded-full bg-amber-100/30 blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
          <div className="flex-1 text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Преміум аромати за <span className="text-amber-500">доступною ціною</span>
            </h1>
            <p className="text-foreground-600 text-lg md:text-xl max-w-xl mx-auto lg:mx-0 mb-8">
              Європейські олії найвищої якості з концентрацією 50%, які не поступаються оригіналам у стійкості та розкритті аромату.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                size="lg" 
                color="primary" 
                className="bg-amber-500 text-white border-amber-500 hover:bg-amber-600"
                as="a" 
                href="#products"
              >
                Переглянути каталог
              </Button>
              <Button 
                size="lg" 
                variant="bordered" 
                className="border-amber-500 text-amber-500 hover:bg-amber-500/10"
                as="a" 
                href="#contact"
              >
                Зв'язатися з нами
              </Button>
            </div>
            <div className="mt-8 flex items-center justify-center lg:justify-start gap-6">
              <div className="flex items-center gap-2">
                <Icon icon="lucide:check-circle" className="text-amber-500" />
                <span className="text-sm">Висока якість</span>
              </div>
              <div className="flex items-center gap-2">
                <Icon icon="lucide:check-circle" className="text-amber-500" />
                <span className="text-sm">Стійкість 24+ годин</span>
              </div>
              <div className="flex items-center gap-2">
                <Icon icon="lucide:check-circle" className="text-amber-500" />
                <span className="text-sm">Безкоштовна доставка</span>
              </div>
            </div>
          </div>
          <div className="flex-1 relative">
            <div className="relative aspect-square max-w-md mx-auto">
              <Image
                removeWrapper
                alt="Преміум парфуми"
                src="https://img.heroui.chat/image/fashion?w=600&h=600&u=perfume1"
                className="object-cover rounded-2xl shadow-xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-lg shadow-lg">
                <div className="flex items-center gap-2">
                  <div className="bg-amber-500 text-white rounded-full w-10 h-10 flex items-center justify-center">
                    <Icon icon="lucide:percent" />
                  </div>
                  <div>
                    <p className="text-xs text-foreground-500">Концентрація</p>
                    <p className="font-bold">50%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};