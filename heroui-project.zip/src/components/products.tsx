import React from "react";
import { Card, CardBody, CardFooter, Button, Image } from "@heroui/react";
import { Icon } from "@iconify/react";

export const Products = () => {
  const products = [
    {
      id: 1,
      name: "Amber Elegance",
      originalBrand: "Inspired by Chanel",
      price: "599 грн",
      image: "https://img.heroui.chat/image/fashion?w=400&h=400&u=perfume2"
    },
    {
      id: 2,
      name: "Ocean Breeze",
      originalBrand: "Inspired by Dior",
      price: "649 грн",
      image: "https://img.heroui.chat/image/fashion?w=400&h=400&u=perfume3"
    },
    {
      id: 3,
      name: "Floral Symphony",
      originalBrand: "Inspired by Gucci",
      price: "599 грн",
      image: "https://img.heroui.chat/image/fashion?w=400&h=400&u=perfume4"
    },
    {
      id: 4,
      name: "Midnight Mystery",
      originalBrand: "Inspired by Tom Ford",
      price: "699 грн",
      image: "https://img.heroui.chat/image/fashion?w=400&h=400&u=perfume5"
    }
  ];

  return (
    <section id="products" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Наші бестселери</h2>
          <p className="text-foreground-600 max-w-2xl mx-auto">
            Найпопулярніші аромати, які підкорили серця наших клієнтів своєю якістю та стійкістю
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="border border-divider overflow-visible">
              <CardBody className="p-0 overflow-visible">
                <div className="relative">
                  <Image
                    removeWrapper
                    alt={product.name}
                    className="w-full aspect-square object-cover"
                    src={product.image}
                  />
                  <div className="absolute top-4 right-4 bg-amber-500 text-white text-xs font-medium px-2 py-1 rounded-full">
                    Бестселер
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold">{product.name}</h3>
                  <p className="text-sm text-foreground-500">{product.originalBrand}</p>
                  <div className="flex items-center gap-1 mt-1">
                    <Icon icon="lucide:star" className="text-amber-500 text-sm" />
                    <Icon icon="lucide:star" className="text-amber-500 text-sm" />
                    <Icon icon="lucide:star" className="text-amber-500 text-sm" />
                    <Icon icon="lucide:star" className="text-amber-500 text-sm" />
                    <Icon icon="lucide:star" className="text-amber-500 text-sm" />
                    <span className="text-xs text-foreground-500 ml-1">(24)</span>
                  </div>
                </div>
              </CardBody>
              <CardFooter className="flex items-center justify-between border-t border-divider p-4">
                <div className="font-semibold text-lg">{product.price}</div>
                <Button 
                  size="sm" 
                  color="primary" 
                  variant="flat" 
                  className="bg-amber-500/10 text-amber-500 hover:bg-amber-500/20"
                >
                  Додати в кошик
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button 
            size="lg" 
            variant="bordered" 
            className="border-amber-500 text-amber-500 hover:bg-amber-500/10"
            as="a" 
            href="#contact"
          >
            Переглянути весь каталог
          </Button>
        </div>
      </div>
    </section>
  );
};