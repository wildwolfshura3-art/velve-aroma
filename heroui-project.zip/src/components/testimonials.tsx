import React from "react";
import { Card, CardBody, Image } from "@heroui/react";
import { Icon } from "@iconify/react";

export const Testimonials = () => {
  const testimonials = [
    {
      id: 1,
      name: "Марія К.",
      text: "Я дуже вимоглива до ароматів, але ці парфуми перевершили всі мої очікування. Стійкість просто вражає - навіть на наступний день відчувається шлейф!",
      rating: 5,
      avatar: "https://img.heroui.chat/image/avatar?w=100&h=100&u=avatar1"
    },
    {
      id: 2,
      name: "Олександр П.",
      text: "Купив дружині в подарунок, і вона в захваті! Каже, що аромат нічим не відрізняється від оригіналу, який коштує в 4 рази дорожче. Тепер і собі замовлю.",
      rating: 5,
      avatar: "https://img.heroui.chat/image/avatar?w=100&h=100&u=avatar2"
    },
    {
      id: 3,
      name: "Ірина В.",
      text: "Дуже задоволена якістю! Раніше купувала оригінальні парфуми, але тепер буду замовляти тільки тут. Економія значна, а якість на висоті.",
      rating: 5,
      avatar: "https://img.heroui.chat/image/avatar?w=100&h=100&u=avatar3"
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-gradient-to-b from-amber-50/50 to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Відгуки наших клієнтів</h2>
          <p className="text-foreground-600 max-w-2xl mx-auto">
            Дізнайтеся, що говорять про нашу продукцію люди, які вже спробували наші аромати
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="border border-amber-200/50">
              <CardBody className="p-6">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Icon key={i} icon="lucide:star" className="text-amber-500" />
                  ))}
                </div>
                <p className="text-foreground-600 mb-6">"{testimonial.text}"</p>
                <div className="flex items-center gap-3">
                  <Image
                    removeWrapper
                    alt={testimonial.name}
                    className="w-10 h-10 rounded-full object-cover"
                    src={testimonial.avatar}
                  />
                  <div>
                    <p className="font-medium">{testimonial.name}</p>
                    <p className="text-xs text-foreground-500">Постійний клієнт</p>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};