import React from "react";
import { Card, CardBody, Input, Textarea, Button } from "@heroui/react";
import { Icon } from "@iconify/react";

export const Contact = () => {
  return (
    <section id="contact" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Зв'яжіться з нами</h2>
          <p className="text-foreground-600 max-w-2xl mx-auto">
            Маєте запитання чи бажаєте зробити замовлення? Заповніть форму нижче, і ми зв'яжемося з вами найближчим часом
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <Card className="border border-divider">
            <CardBody className="p-6">
              <h3 className="text-xl font-semibold mb-6">Напишіть нам</h3>
              <form className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Input
                    label="Ім'я"
                    placeholder="Введіть ваше ім'я"
                    variant="bordered"
                  />
                  <Input
                    label="Телефон"
                    placeholder="+380 XX XXX XX XX"
                    type="tel"
                    variant="bordered"
                  />
                </div>
                <Input
                  label="Email"
                  placeholder="your@email.com"
                  type="email"
                  variant="bordered"
                />
                <Textarea
                  label="Повідомлення"
                  placeholder="Напишіть ваше повідомлення або запитання"
                  variant="bordered"
                  minRows={4}
                />
                <Button 
                  className="w-full bg-amber-500 text-white hover:bg-amber-600"
                >
                  Надіслати повідомлення
                </Button>
              </form>
            </CardBody>
          </Card>

          <div className="space-y-8">
            <div>
              <h3 className="text-xl font-semibold mb-6">Контактна інформація</h3>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="bg-amber-500/10 p-3 rounded-lg">
                    <Icon icon="lucide:phone" className="text-amber-500" />
                  </div>
                  <div>
                    <p className="font-medium">Телефон</p>
                    <p className="text-foreground-600">+380 98 765 4321</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-amber-500/10 p-3 rounded-lg">
                    <Icon icon="lucide:mail" className="text-amber-500" />
                  </div>
                  <div>
                    <p className="font-medium">Email</p>
                    <p className="text-foreground-600">info@aromaperfume.com</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-amber-500/10 p-3 rounded-lg">
                    <Icon icon="lucide:map-pin" className="text-amber-500" />
                  </div>
                  <div>
                    <p className="font-medium">Адреса</p>
                    <p className="text-foreground-600">м. Київ, вул. Хрещатик, 22</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-6">Соціальні мережі</h3>
              <div className="flex flex-wrap gap-4">
                <Button
                  isIconOnly
                  size="lg"
                  variant="flat"
                  className="bg-pink-500/10 text-pink-500 hover:bg-pink-500/20"
                  as="a"
                  href="https://instagram.com"
                  target="_blank"
                >
                  <Icon icon="logos:instagram-icon" className="text-2xl" />
                </Button>
                <Button
                  isIconOnly
                  size="lg"
                  variant="flat"
                  className="bg-black/10 text-black hover:bg-black/20"
                  as="a"
                  href="https://tiktok.com"
                  target="_blank"
                >
                  <Icon icon="logos:tiktok-icon" className="text-2xl" />
                </Button>
                <Button
                  isIconOnly
                  size="lg"
                  variant="flat"
                  className="bg-blue-500/10 text-blue-500 hover:bg-blue-500/20"
                  as="a"
                  href="https://t.me/channel"
                  target="_blank"
                >
                  <Icon icon="logos:telegram" className="text-2xl" />
                </Button>
              </div>
              <p className="mt-4 text-foreground-600">
                Підписуйтесь на наші соціальні мережі, щоб бути в курсі новинок та акцій
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};