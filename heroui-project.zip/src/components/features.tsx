import React from "react";
import { Card, CardBody } from "@heroui/react";
import { Icon } from "@iconify/react";

export const Features = () => {
  const features = [
    {
      icon: "lucide:flask-conical",
      title: "Висока концентрація",
      description: "50% концентрація ароматичних олій забезпечує інтенсивний та стійкий аромат"
    },
    {
      icon: "lucide:clock",
      title: "Тривала стійкість",
      description: "Наші аромати тримаються на шкірі до 24 годин, а на одязі до кількох днів"
    },
    {
      icon: "lucide:sparkles",
      title: "Преміум якість",
      description: "Використовуємо лише найкращі європейські олії, які не поступаються оригіналам"
    },
    {
      icon: "lucide:heart",
      title: "Гіпоалергенні",
      description: "Безпечні формули без спирту, які підходять навіть для чутливої шкіри"
    },
    {
      icon: "lucide:leaf",
      title: "Екологічність",
      description: "Наша продукція не тестується на тваринах і має екологічне пакування"
    },
    {
      icon: "lucide:wallet",
      title: "Доступна ціна",
      description: "Преміальна якість за ціною, яка в 3-4 рази нижча за оригінальні аромати"
    }
  ];

  return (
    <section id="features" className="py-20 bg-gradient-to-b from-background to-amber-50/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Чому обирають нас</h2>
          <p className="text-foreground-600 max-w-2xl mx-auto">
            Наші парфуми поєднують у собі найкращі якості преміальних ароматів за доступною ціною
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="border border-amber-200/50 bg-white/80 backdrop-blur-sm">
              <CardBody className="p-6">
                <div className="bg-amber-500/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Icon icon={feature.icon} className="text-amber-500 text-2xl" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-foreground-600">{feature.description}</p>
              </CardBody>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};