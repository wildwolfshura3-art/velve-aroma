import React from "react";
import { Button } from "@heroui/react";
import { Icon } from "@iconify/react";

export const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  return (
    <nav className="sticky top-0 z-50 w-full bg-background/80 backdrop-blur-md border-b border-divider">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon icon="lucide:droplets" className="text-amber-500 text-2xl" />
          <span className="text-xl font-semibold tracking-tight">AROMA</span>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          <a href="#home" className="text-sm font-medium hover:text-amber-500 transition-colors">
            Головна
          </a>
          <a href="#features" className="text-sm font-medium hover:text-amber-500 transition-colors">
            Переваги
          </a>
          <a href="#products" className="text-sm font-medium hover:text-amber-500 transition-colors">
            Продукція
          </a>
          <a href="#testimonials" className="text-sm font-medium hover:text-amber-500 transition-colors">
            Відгуки
          </a>
          <a href="#contact" className="text-sm font-medium hover:text-amber-500 transition-colors">
            Контакти
          </a>
        </div>

        <div className="hidden md:flex items-center gap-4">
          <Button 
            size="sm" 
            color="primary" 
            variant="flat" 
            className="bg-amber-500/10 text-amber-500 hover:bg-amber-500/20"
            as="a" 
            href="#contact"
          >
            Замовити
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <Button
          isIconOnly
          variant="light"
          className="md:hidden"
          onPress={() => setIsMenuOpen(!isMenuOpen)}
        >
          <Icon icon={isMenuOpen ? "lucide:x" : "lucide:menu"} className="text-xl" />
        </Button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute w-full bg-background border-b border-divider shadow-md">
          <div className="container mx-auto px-4 py-4 flex flex-col gap-4">
            <a 
              href="#home" 
              className="py-2 text-sm font-medium hover:text-amber-500 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Головна
            </a>
            <a 
              href="#features" 
              className="py-2 text-sm font-medium hover:text-amber-500 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Переваги
            </a>
            <a 
              href="#products" 
              className="py-2 text-sm font-medium hover:text-amber-500 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Продукція
            </a>
            <a 
              href="#testimonials" 
              className="py-2 text-sm font-medium hover:text-amber-500 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Відгуки
            </a>
            <a 
              href="#contact" 
              className="py-2 text-sm font-medium hover:text-amber-500 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Контакти
            </a>
            <Button 
              size="sm" 
              color="primary" 
              variant="flat" 
              className="bg-amber-500/10 text-amber-500 hover:bg-amber-500/20 w-full"
              as="a" 
              href="#contact"
              onClick={() => setIsMenuOpen(false)}
            >
              Замовити
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
};