import React from "react";
import { Divider } from "@heroui/react";
import { Icon } from "@iconify/react";

export const Footer = () => {
  return (
    <footer className="bg-foreground-50 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Icon icon="lucide:droplets" className="text-amber-500 text-2xl" />
              <span className="text-xl font-semibold tracking-tight">AROMA</span>
            </div>
            <p className="text-foreground-600 mb-4">
              Преміальні парфуми за доступною ціною. Європейські олії найвищої якості з концентрацією 50%.
            </p>
            <div className="flex gap-4">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-foreground-500 hover:text-pink-500 transition-colors">
                <Icon icon="logos:instagram-icon" className="text-xl" />
              </a>
              <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer" className="text-foreground-500 hover:text-black transition-colors">
                <Icon icon="logos:tiktok-icon" className="text-xl" />
              </a>
              <a href="https://t.me/channel" target="_blank" rel="noopener noreferrer" className="text-foreground-500 hover:text-blue-500 transition-colors">
                <Icon icon="logos:telegram" className="text-xl" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Навігація</h4>
            <ul className="space-y-2">
              <li><a href="#home" className="text-foreground-600 hover:text-amber-500 transition-colors">Головна</a></li>
              <li><a href="#features" className="text-foreground-600 hover:text-amber-500 transition-colors">Переваги</a></li>
              <li><a href="#products" className="text-foreground-600 hover:text-amber-500 transition-colors">Продукція</a></li>
              <li><a href="#testimonials" className="text-foreground-600 hover:text-amber-500 transition-colors">Відгуки</a></li>
              <li><a href="#contact" className="text-foreground-600 hover:text-amber-500 transition-colors">Контакти</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Інформація</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-foreground-600 hover:text-amber-500 transition-colors">Про нас</a></li>
              <li><a href="#" className="text-foreground-600 hover:text-amber-500 transition-colors">Доставка і оплата</a></li>
              <li><a href="#" className="text-foreground-600 hover:text-amber-500 transition-colors">Повернення</a></li>
              <li><a href="#" className="text-foreground-600 hover:text-amber-500 transition-colors">Політика конфіденційності</a></li>
              <li><a href="#" className="text-foreground-600 hover:text-amber-500 transition-colors">Умови використання</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Контакти</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <Icon icon="lucide:phone" className="text-amber-500 mt-1" />
                <span className="text-foreground-600">+380 98 765 4321</span>
              </li>
              <li className="flex items-start gap-2">
                <Icon icon="lucide:mail" className="text-amber-500 mt-1" />
                <span className="text-foreground-600">info@aromaperfume.com</span>
              </li>
              <li className="flex items-start gap-2">
                <Icon icon="lucide:map-pin" className="text-amber-500 mt-1" />
                <span className="text-foreground-600">м. Київ, вул. Хрещатик, 22</span>
              </li>
              <li className="flex items-start gap-2">
                <Icon icon="lucide:clock" className="text-amber-500 mt-1" />
                <span className="text-foreground-600">Пн-Пт: 10:00 - 19:00<br />Сб-Нд: 11:00 - 17:00</span>
              </li>
            </ul>
          </div>
        </div>

        <Divider className="my-6" />

        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-foreground-500 text-sm mb-4 md:mb-0">
            © 2024 AROMA. Всі права захищені.
          </p>
          <div className="flex items-center gap-4">
            <img src="https://img.heroui.chat/image/finance?w=40&h=25&u=visa" alt="Visa" className="h-6 object-contain" />
            <img src="https://img.heroui.chat/image/finance?w=40&h=25&u=mastercard" alt="Mastercard" className="h-6 object-contain" />
            <img src="https://img.heroui.chat/image/finance?w=40&h=25&u=paypal" alt="PayPal" className="h-6 object-contain" />
          </div>
        </div>
      </div>
    </footer>
  );
};