import { heroui } from "@heroui/react";

/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "./node_modules/@heroui/theme/dist/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  darkMode: "class",
  plugins: [
    heroui({
      layout: {
        fontSize: {
          tiny: "0.75rem",
          small: "0.875rem",
          medium: "1rem",
          large: "1.125rem",
        },
        lineHeight: {
          tiny: "1rem",
          small: "1.25rem",
          medium: "1.5rem",
          large: "1.75rem",
        },
        radius: {
          small: "6px",
          medium: "8px",
          large: "12px",
        },
      },
      themes: {
        light: {
          colors: {
            primary: {
              50: "#fdf6e6",
              100: "#fbecc8",
              200: "#f8dd9b",
              300: "#f5cd6d",
              400: "#f2be40",
              500: "#d9a012",
              600: "#b3850f",
              700: "#8c680c",
              800: "#664c09",
              900: "#3f2f05",
              DEFAULT: "#d9a012",
              foreground: "#ffffff"
            }
          }
        }
      }
    })
  ]
}
